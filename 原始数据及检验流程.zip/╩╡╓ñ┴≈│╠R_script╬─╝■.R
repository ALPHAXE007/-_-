***********所有使用到的文件需存放在“我的电脑-文档”文件夹内才能正确读取
一、导入数据
install.packages(“readxl”)
library(readxl)
df<-read_excel("实证检验原始数据.xls")
str(df)
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
二、实证检验
（一）格兰杰检验
1.	安装和加载必要的包：
install.packages("plm")
library(plm)
install.packages("lmtest")
library(lmtest)

2.	将导入的数据框转化为面板数据：
pdata <- pdata.frame(df, index = c("code", "enddate"))
4.	进行面板格兰杰因果检验并输出结果（正向和反向因果）
grangertest(Res_nonelinear ~ First_tone, data = pdata, order = 4)
grangertest(First_tone ~ Res_nonelinear, data = pdata, order = 4)

（二）线性回归（略）

（三）GAM检验结果：
1.	导入解释变量分组的数据集，并将其命名为df1：
df1<-read_excel("解释变量分组结果.xls")
str(df1)

2.	对NUM和First_tone进行非线性拟合
install.packages("gam")
library(gam)
install.packages("mgcv")
library(mgcv)
model1<-gam(NUM~s(First_tone),data=df1)

3.	图示First_tone对NUM的非线性影响（得到文中图1）：
（1）	创建预测数据
new_data <- data.frame(First_tone = seq(min(df1$First_tone), max(df1$First_tone), length.out = 100))
（2）	预测 s(First_tone) 的值和置信区间
preds <- predict(model1, newdata = new_data, type = "terms", se.fit = TRUE)
smooth_term <- preds$fit[, "s(First_tone)"]
se <- preds$se.fit[, "s(First_tone)"]
（3）	将结果添加到 new_data
new_data$smooth_term <- smooth_term
new_data$upper <- smooth_term + 2 * se
new_data$lower <- smooth_term - 2 * se
（4）	使用 ggplot2 绘图
ggplot(new_data, aes(x = First_tone, y = smooth_term)) +
  geom_line(linewidth = 0.75) +  # 平滑曲线
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.2) +  # 添加置信区间
  theme_classic() + 
  theme(
    text = element_text(size = 20),
    axis.line = element_line(linewidth = 0.75)
  ) +
  labs(x = "First Tone", y = "s(First Tone)")

4.	图示First_tone与NUM预测值之间的非线性关系（得到文中图2）：
（1）	设置预测值
df1$smooth_term <- predict(model1, type = "terms")[, "s(First_tone)"]
df1$predicted_num <- predict(model1) 
（2）	使用 ggplot2 绘图
ggplot(df1, aes(x = First_tone, y = predicted_num)) +  # 将 y 轴映射为 predicted_num
  geom_point(alpha = 0.5) +  # 绘制预测值的散点图
  geom_line(aes(y = smooth_term + coef(model1)[1]), linewidth = 0.75, color = "black") +  # 绘制 s(First_tone) 的平滑曲线
  theme_classic() + 
  theme(
    text = element_text(size = 20),
    axis.line = element_line(linewidth = 0.75)
  ) +
  labs(x = "First Tone", y = "Predicted NUM")  # 修改纵轴标签为 Predicted NUM
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
三、稳健性检验（仅GAM拟合部分）
1.	导入解释变量分组的数据集，并将其命名为df2：
df2<-read_excel("替代解释变量分组结果.xls")
str(df2)

2.	对NUM和Second_tone进行非线性拟合
model2<-gam(NUM~s(Second_tone),data=df2)

3.	图示Second_tone对NUM的非线性影响（得到文中图3）：
（1）	创建预测数据
new_data <- data.frame(Second_tone = seq(min(df2$Second_tone), max(df2$Second_tone), length.out = 100))
（2）	预测 s(Second_tone) 的值和置信区间
preds <- predict(model2, newdata = new_data, type = "terms", se.fit = TRUE)
smooth_term <- preds$fit[, "s(Second_tone)"]
se <- preds$se.fit[, "s(Second_tone)"]
（3）	将结果添加到 new_data
new_data$smooth_term <- smooth_term
new_data$upper <- smooth_term + 2 * se
new_data$lower <- smooth_term - 2 * se
（4）	使用 ggplot2 绘图
ggplot(new_data, aes(x = Second_tone, y = smooth_term)) +
  geom_line(linewidth = 0.75) +  # 平滑曲线
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.2) +  # 添加置信区间
  theme_classic() + 
  theme(
    text = element_text(size = 20),
    axis.line = element_line(linewidth = 0.75)
  ) +
  labs(x = "Second_tone", y = "s(Second_tone)")

4.	图示Second_tone与NUM预测值之间的非线性关系（得到文中图4）：
（1）	设置预测值
df2$smooth_term <- predict(model2, type = "terms")[, "s(Second_tone)"]
df2$predicted_num <- predict(model2) 
（2）	使用 ggplot2 绘图
ggplot(df2, aes(x = Second_tone, y = predicted_num)) +  # 将 y 轴映射为 predicted_num
  geom_point(alpha = 0.5) +  # 绘制预测值的散点图
  geom_line(aes(y = smooth_term + coef(model2)[1]), linewidth = 0.75, color = "black") +  # 绘制 s(First_tone) 的平滑曲线
  theme_classic() + 
  theme(
    text = element_text(size = 20),
    axis.line = element_line(linewidth = 0.75)
  ) +
  labs(x = "Second_tone", y = "Predicted NUM")  # 修改纵轴标签为 Predicted NUM

