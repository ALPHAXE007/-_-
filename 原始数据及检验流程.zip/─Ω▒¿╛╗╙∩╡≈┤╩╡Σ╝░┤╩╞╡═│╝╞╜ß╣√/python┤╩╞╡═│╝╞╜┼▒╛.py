# coding=utf-8
import xlwt
import os
# 加载txt列表寻找关键词并保存到excel
def matchKeyWords(ThePath, keyWords,aim_path):
    dir_list = os.listdir(ThePath)
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet = book.add_sheet('年报关键词词频统计', cell_overwrite_ok=True)
    sheet.write(0, 0, '股票代码')
    sheet.write(0, 1, '股票名称')
    sheet.write(0, 2, '年份')
    for i,c_word in enumerate(keyWords):
        sheet.write(0, i+3, c_word)
    index=0
    for dir in dir_list:
        dir_path = ThePath + '\\' + dir
        files = os.listdir(dir_path)
        for file in files:
            if os.path.splitext(file)[-1] == ".txt":
                txt_path = os.path.join(dir_path, file)
                stock_code = dir.split("-")[0]
                stock_name = dir.split("-")[1]
                year = file[0:4]
                sheet.write(index + 1, 0, stock_code)
                sheet.write(index + 1, 1, stock_name)
                sheet.write(index + 1, 2, year)
                print(f'正在统计{dir}-{file}')
                with open(txt_path, "r", encoding='utf-8', errors='ignore')as fp:
                    text = fp.readlines()
                    for ind,word in enumerate(keyWords):
                        num = 0
                        for line in text:
                            num += line.count(word)
                        word_freq=num
                        sheet.write(index + 1, ind + 3, str(word_freq))
                index+=1
    book.save(aim_path)

ThePath= r'E:\BaiduNetdiskDownload\年报文本\剔除重污染行业结果'
aim_path=r'E:\桌面\Data for paper\词库\年报中提取的'
keywords = ['压力', '风险', '挑战', '约束', '紧缺', '波动', '极端', '不利', '事故', '污染', '高碳', '中断', '恶化', '损失', '缺陷', '违规', '纠纷', '处罚', '诉讼', '偏紧', '短缺', '冲击', '困难', '问题', '隐患', '延误', '不足', '下降', '减少', '偏低', '回落', '乏力', '动荡', '不确定性', '遇冷', '失衡', '飙升', '萎缩', '亏损', '放缓', '受限', '考验', '滥用', '侵占', '减持', '摊薄', '降价', '负债', '欺诈', '虚高', '关停', '违约', '逾期', '侵袭', '毁损', '报废', '闲置', '干扰', '损害', '脆弱', '濒危', '破坏', '侵犯', '暴力', '冲突', '歧视', '死亡', '工伤', '流失', '泄露', '贿赂', '诽谤', '诬告', '陷害', '失信', '堵塞', '沉积', '浪费', '老旧', '漏水', '损坏', '篡改', '迟缓', '搬迁', '伤亡', '麻痹', '侥幸', '水灾', '混乱', '严重', '缺乏', '失职', '滞后', '停滞', '失控', '腐败', '不正当', '误导', '遗漏']
matchKeyWords(ThePath, keywords,f'{aim_path}\非重污染行业消极词频（测试）.xls')
